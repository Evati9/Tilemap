﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MonoGame.Extended;
using MonoGame.Extended.Collisions;

namespace MonoGame.Extended.Collisions.ICollisionActor
{
    internal interface ICollisionActor
    {

    }
}
