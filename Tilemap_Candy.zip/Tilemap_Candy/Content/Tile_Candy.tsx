<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Tile_Candy" tilewidth="32" tileheight="32" tilecount="70" columns="14">
 <image source="Tile_Candy.png" width="448" height="160"/>
</tileset>
