<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Fountain_Candy_1" tilewidth="32" tileheight="32" tilecount="100" columns="10">
 <image source="Fountain_Candy_1.png" width="320" height="320"/>
</tileset>
