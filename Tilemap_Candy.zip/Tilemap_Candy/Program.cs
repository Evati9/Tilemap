﻿
using var game = new Tilemap_Candy.Game1();
game.Run();
